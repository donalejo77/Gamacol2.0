<!DOCTYPE >
<html >
<head>
    <title>Document</title>
    <link rel="stylesheet" href="CSS/hogar estilos.css">
</head>



<body>

<nav></nav>

<main> 
     <h2>Aseo para el hogar</h2>  
    
    <section>
   <article>
       <h4>Jabón para loza</h4>
     <img src="img/Jabón para lavar loza.png" class="esta es una imagen de prueba"></br>

         <p>Categoria:Aseo para el hogar </p><br>
         <p>Cantidad:250gr</p><br>
         <p>Valor:$5.700</p></br>

         <input type="button" style="height:10px;width:10px;margin-right:5px">Añadir al carrito
            
    </article> 
 
 
    <article class="detergente-clorox">
      <h4>Detergente liquido clorox</h4>
      <img src="img/Detergente líquido.png" class="esta es una imagen de prueba"></br>

          <p>Categoria:Aseo para el hogar </p><br>
          <p>Cantidad:1000ml</p><br>
          <p>Valor:$4.500</p></br>
          <input type="button" style="height:10px;width:10px;margin-right:5px">Añadir al carrito
        
    </article>


    <article class="jabon-rey">

        <h4>Jabón rey</h4>
         <img src="img/Jabón Rey.png" class="esta es una imagen de prueba"></br>

             <p>Categoria:Aseo para el hogar </p><br>
             <p>Cantidad:x3 ud</p><br>
             <p>Valor:$8.000</p></br>
             <input type="button" style="height:10px;width:10px;margin-right:5px">Añadir al carrito
    </article>


    <article class="suave">
             <h4>suavizante</h4>
             <img src="img/suavizante.png" class="esta es una imagen de prueba">
             </br>
             <p>Categoria:Aseo para el hogar </p><br>
             <p>Cantidad:700 ml</p><br>
             <p>Valor:$7.000</p><br>
             <input type="button" style="height:10px;width:10px;margin-right:5px">Añadir al carrito
   </article>
   </section>
</main>


<footer></footer>










</body>
</html>