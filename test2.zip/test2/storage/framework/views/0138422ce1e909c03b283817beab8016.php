<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
   <H1>hola buenas nosheees</H1>
    <nav>
        <ol><li>
            <a href="">Inicios</a>
            <a href="">Ofertas</a>
            <a href="">Promociones</a>
            <a href="">Ubicación del restaurante</a>
            <a href="">Pagina de contacto</a>
        </li></ol>
    </nav>

    <aside>
        <section><h3><i>Menu del dia</i></h3></section>
        <section></section>
    </aside>

    <footer></footer>
</body>
</html><?php /**PATH C:\Users\Adminsena\test2\resources\views/comidas.blade.php ENDPATH**/ ?>